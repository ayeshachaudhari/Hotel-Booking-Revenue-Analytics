# Hotel Booking & Revenue Analytics Dataset

These CSV files are a **synthetic sample dataset** prepared for a Power BI portfolio project. They are not real customer or hotel records.

## Files
- `bookings.csv` — booking-level sample records
- `reviews.csv` — sample hotel reviews and ratings
- `hotel_revenue.csv` — hotel-wise completed revenue summary
- `monthly_revenue.csv` — monthly revenue summary
- `booking_status_summary.csv` — booking status counts
- `hotel_cancellation_rate.csv` — cancellation rates by hotel
- `room_type_revenue.csv` — revenue by room type
- `service_revenue.csv` — additional service revenue

## Important
Some summary CSVs are supplied separately for dashboard visuals. Since this is a demonstration dataset, always use the summary files for the corresponding summary charts rather than assuming every summary can be recreated exactly from the sample row-level records.
